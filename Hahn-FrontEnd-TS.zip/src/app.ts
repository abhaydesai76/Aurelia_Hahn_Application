import 'bootstrap/dist/css/bootstrap.css';
import 'font-awesome/css/font-awesome.css';  
import {DialogService} from 'aurelia-dialog';
import {Prompt} from './components/prompt';
import {inject, NewInstance} from 'aurelia-framework';
import {ValidationController, ValidationRules} from 'aurelia-validation';
import {HttpClient, json} from 'aurelia-fetch-client';

interface HahnApplicant {
  id?: number;
  name: string;
  familyName: string;
  age: number;
  address: string;
  eMailAddress: string;
  countryOfOrigin: string;
  hired: boolean;
}

@inject(NewInstance.of(ValidationController), DialogService, HttpClient)

export class App {

    applicant: HahnApplicant;    
    updatedApplicant: HahnApplicant;
    toBeUpdatedApplicant: HahnApplicant;    
    applicants: Array<HahnApplicant>;

    hiredStatuses = [     
        {id:0, name: 'Hired'},
        {id:1, name: 'Not Hired'}     
    ]

    selectedHiredStatus: string = 'Not Hired';

    
    // toBeUpdatedApplicant = {};
    // toBeDeletedApplicant = {};
    // controller = null;

    httpClient = new HttpClient();

    constructor(private controller: ValidationController, private dialogService: DialogService, private http: HttpClient) {
      // window.alert('Inside Constructor');

      this.controller = controller;      
      this.dialogService = dialogService;

      // ValidationRules.customRule('ValidCountry',(value, obj) => value === 'India');

      ValidationRules
        .ensure('name').required().minLength(5).on(this)
        .ensure('familyName').required().minLength(5).on(this)
        .ensure('address').required().minLength(10).on(this)
        .ensure('eMailAddress').required().email().on(this)
        .ensure('age').required().min(20).max(60).on(this);
        // .ensure('country').required().then().satisfiesRule('ValidCountry').on(this);

      http.configure(config => {
        config
          .withBaseUrl('https://localhost:44348/Applicant/')
          .withDefaults({
            credentials: 'same-origin',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              'X-Requested-With': 'Fetch'
            }
          });
      });
      
      this.http = http;
    }

    getApplicants() {
      this.http.fetch('GetAllApplicants')
        .then(response => response.json())
        .then(applicants => {
          console.log('value of applicants in getApplicants', applicants);
          this.applicants = applicants;
        })
        .catch(error => {
          console.log(`Error retrieving applicants. ${error}`);
          return [];
        });
    }

    attached() {
      // window.alert('Inside Attached');            
    }

    bind() 
    {
      // window.alert('Inside Bind');      
    }    

    activate() 
    {
      // window.alert('Inside Activate');      
      this.getApplicants();
    }

    created() {
      // window.alert('Inside Created');            
    }

    add() {                
      this.dialogService.open({ viewModel: Prompt, model: 'Do you want to save this record?', lock: false }).whenClosed(response => {
          if (!response.wasCancelled)
          {
            this.validateDetailsSave();
          }
          else
          {
            console.log('Doesnot want to save at this moment');
          }
        });      
    }

    update(id: number) {
      this.dialogService.open({ viewModel: Prompt, model: 'Do you want to update this record?', lock: false }).whenClosed(response => {
        if (!response.wasCancelled)
        {
          console.log('value of applicants : ', this.applicants);
          this.toBeUpdatedApplicant = this.applicants.find(applicant => applicant.id === Number(id));
          console.log('toBeUpdatedApplicant : ', this.toBeUpdatedApplicant);

          applicant.id = id;
          this.applicant.name = this.toBeUpdatedApplicant.name;
          this.applicant.familyName = this.toBeUpdatedApplicant.familyName;
          this.applicant.age = this.toBeUpdatedApplicant.age;
          this.applicant.address = this.toBeUpdatedApplicant.address;
          this.applicant.eMailAddress = this.toBeUpdatedApplicant.eMailAddress;
          this.applicant.countryOfOrigin = this.toBeUpdatedApplicant.countryOfOrigin;
          this.applicant.hired = this.toBeUpdatedApplicant.hired;
        }
        else
        {
          console.log('Doesnot want to update at this moment');
        }
      });      
    }

    validateDetailsSave() {
      this.controller.validate()
        .then(result => {
          if (result.valid)
          {
            // if (Object.keys(this.toBeUpdatedApplicant).length === 0)
            if (this.toBeUpdatedApplicant !== null)
            {
              console.log('value of selectedHiredStatus : ', this.selectedHiredStatus);
              this.selectedHiredStatus === 'Hired' ? this.applicant.hired = true : this.applicant.hired = false;

              let Applicant: HahnApplicant = { name: this.applicant.name, familyName: this.applicant.familyName, address: this.applicant.address, 
                                age: Number(this.applicant.age), eMailAddress: this.applicant.eMailAddress, 
                                countryOfOrigin: this.applicant.countryOfOrigin, hired: Boolean(this.applicant.hired) };

              console.log('value of Applicant : ', Applicant);

              this.http
              .fetch('SaveApplicant', {
                method: 'post',
                body: json(Applicant)
              })
              .then(response => response.json())
              .then(createdApplicant => {
                return createdApplicant;
              })
                .catch(error => {
                    console.log(`Error adding Applicant. ${error}`);
              });

              this.dialogService.open({ viewModel: Prompt, model: 'Record saved successfully...', lock: false })
            }
            else
            {
              this.selectedHiredStatus === 'Hired' ? this.applicant.hired = true : this.applicant.hired = false;
              
              let UpdatedApplicant: HahnApplicant | any = this.applicants.filter(applicant => applicant.id === this.applicant.id);

              UpdatedApplicant = { id: this.applicant.id, name: this.applicant.name, familyName: this.applicant.familyName, 
                                  address: this.applicant.address, age: Number(this.applicant.age), 
                                  eMailAddress: this.applicant.eMailAddress, 
                                  countryOfOrigin: this.applicant.countryOfOrigin, hired: Boolean(this.applicant.hired) };

              console.log('value of updatedApplicant : ', json(this.updatedApplicant));

              this.http
              .fetch(`UpdateApplicant/${this.updatedApplicant.id}`, {
                method: 'put',
                body: json(this.updatedApplicant)
              })
              .then(response => response.json())
              .then(updatedApplicant => {
                return updatedApplicant;
              })
                .catch(error => {
                    console.log(`Error updating Applicant. ${error}`);
              });

              this.dialogService.open({ viewModel: Prompt, model: 'Record updated successfully...', lock: false })
            }
          }          

          this.clearForm();

          location.reload();
        })
    }

    delete(id: number) {
      this.dialogService.open({ viewModel: Prompt, model: 'Do you want to delete this record?', lock: false }).whenClosed(response => {
        if (!response.wasCancelled)
        {
          this.http
          .fetch(`DeleteApplicant/${id}`, {
            method: 'delete'
          })
          .then(response => response.json())
          .then(responseMessage => {
            return responseMessage;
          })
            .catch(error => {
                console.log(`Error deleting Applicant. ${error}`);
          });

          this.dialogService.open({ viewModel: Prompt, model: 'Record deleted successfully...', lock: false })

          location.reload();
        }
        else
        {
          console.log('Doesnot want to delete at this moment');
        }
      }); 
    }

    reset() {
      // alert("Reset button clicked !!!");
      this.controller.reset();
      this.clearForm();
    }
    
    clearForm() {
      this.applicant.id = 0;
      this.applicant.name = '';
      this.applicant.familyName = '';
      this.applicant.age = 0;
      this.applicant.address = '';
      this.applicant.eMailAddress = '';
      this.applicant.countryOfOrigin = '';
      this.applicant.hired = false;
    }
}
