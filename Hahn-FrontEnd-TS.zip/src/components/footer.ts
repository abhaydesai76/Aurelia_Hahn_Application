export class Footer {
  constructor() {
    
  }
}
