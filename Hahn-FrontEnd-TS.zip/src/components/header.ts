import {I18N} from 'aurelia-i18n';

export class Header {    
  appTitle = "Hahn Applicants";

  static inject = [I18N];

  constructor(private i18n: I18N) {
    this.i18n = i18n;
  }

  setLocale(locale: string) {
    this.i18n.setLocale(locale);
  }
}
