import {DialogController} from 'aurelia-dialog';

export class Prompt {
  static inject = [DialogController];

  answer: string;
  message: string;

   constructor(private controller: DialogController) {
      this.controller = controller;
      this.answer = null;

      controller.settings.centerHorizontalOnly = true;
   }
   activate(message: string) {
      this.message = message;
   }
}
