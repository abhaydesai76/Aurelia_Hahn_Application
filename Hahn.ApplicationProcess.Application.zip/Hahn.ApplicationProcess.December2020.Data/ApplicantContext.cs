﻿using System;
using Microsoft.EntityFrameworkCore;
using Hahn.ApplicationProcess.December2020.Domain;

namespace Hahn.ApplicationProcess.December2020.Data
{
    public class ApplicantContext : DbContext
    {
        public ApplicantContext (DbContextOptions<ApplicantContext> options)
                                        : base(options)
        {
            
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase(databaseName: "Applicants");
        }

        public DbSet<Applicant> Applicants { get; set; }
        
    }
}
