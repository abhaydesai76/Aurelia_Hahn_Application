﻿using System;
using FluentValidation;
using System.ComponentModel.DataAnnotations;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Hahn.ApplicationProcess.December2020.Domain
{
    /// <summary>
    ///  Controller for Applicant Operations
    /// </summary>
    public class Applicant
    {        
        [Key, Required]
        public int Id { get; set; }

        /// <example>TestName1</example>
        [Required]
        public string Name { get; set; }

        /// <example>TestFamilyName1</example>
        [Required]
        public string FamilyName { get; set; }

        /// <example>TestAddress1</example>
        public string Address { get; set; }

        /// <example>India</example>
        public string CountryOfOrigin { get; set; }

        /// <example>test1@test.com</example>
        [Required]
        public string EMailAddress { get; set; }

        /// <example>25</example>
        public int Age { get; set; }

        /// <example>true</example>
        [DefaultValue(false)]
        public bool Hired { get; set; }
    }

    public class ApplicantValidator : AbstractValidator<Applicant>
    {
        static readonly HttpClient client = new HttpClient();
        public ApplicantValidator()
        {
            RuleFor(x => x.Name).MinimumLength(5).WithMessage("Please specify a name of minimum length of 5 characters");
            RuleFor(x => x.FamilyName).MinimumLength(5).WithMessage("Please specify a familyname of minimum length of 5 characters");
            RuleFor(x => x.Address).MinimumLength(10).WithMessage("Please specify an address of minimum length of 10 characters");
            RuleFor(x => x.EMailAddress).EmailAddress().WithMessage("Please specify a valid email address");
            RuleFor(x => x.Age).InclusiveBetween(20, 60).WithMessage("Please enter age between 20 and 60.");
            RuleFor(x => x.Hired).NotNull();
            RuleFor(x => x.CountryOfOrigin).NotEmpty().MustAsync(EnterAValidCountry).WithMessage("Please enter a valid country");
        }

        private async Task<bool> EnterAValidCountry(string CountryOfOrigin, CancellationToken token)
        {
            try
            {
                HttpResponseMessage response = await client.GetAsync("https://restcountries.eu/rest/v2/name/" + CountryOfOrigin, token);

                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (HttpRequestException e)
            {
                return false;
            }
        }
    }
}
