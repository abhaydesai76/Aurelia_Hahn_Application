using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.HttpOverrides;
using Hahn.ApplicationProcess.December2020.Data;
using FluentValidation;
using FluentValidation.AspNetCore;
using Hahn.ApplicationProcess.December2020.Domain;
using System.IO;

namespace Hahn.ApplicationProcess.December2020.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicantContext>(opt => opt.UseInMemoryDatabase("Applicants"));

            services.AddMvc().AddFluentValidation();

            services.AddControllers();

            services.AddTransient<IValidator<Applicant>, ApplicantValidator>() ;

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v2020", new OpenApiInfo 
                                                        { Title = "Hahn.ApplicationProcess.December2020.Web", 
                                                            Version = "v2020",
                                                            Description = "Sample application being created for Hahn Assignment",
                                                            Contact = new OpenApiContact
                                                            {
                                                                Name = "Abhay Desai",
                                                                Email = "abhaydesai76@gmail.com"
                                                            }
                                       });
                
                var filePath = Path.Combine(System.AppContext.BaseDirectory, "Hahn.ApplicationProcess.December2020.Domain.xml");
                c.IncludeXmlComments(filePath);

                c.EnableAnnotations();
            });

            services.AddLogging(options =>
                {
                    options.AddFilter("Microsoft", LogLevel.Information)
                                    .AddFilter("System", LogLevel.Error);
                }
            );

            services.AddCors();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseCors(options => options.WithOrigins("http://localhost:8080").AllowAnyHeader().AllowAnyOrigin().AllowAnyMethod());

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

                app.UseSwagger();

                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v2020/swagger.json", "hahn.applicationprocess.december2020.web v1"));
            }

            app.UseHttpsRedirection(); 
            
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseForwardedHeaders(new ForwardedHeadersOptions
            {
                ForwardedHeaders = ForwardedHeaders.All
            });            
        }
    }
}
