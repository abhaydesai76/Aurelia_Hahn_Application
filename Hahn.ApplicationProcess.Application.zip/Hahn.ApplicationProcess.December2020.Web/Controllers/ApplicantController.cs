﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Hahn.ApplicationProcess.December2020.Domain;
using Hahn.ApplicationProcess.December2020.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;

namespace Hahn.ApplicationProcess.December2020.Web.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Produces("application/json")]
    public class ApplicantController : ControllerBase
    {
        private readonly ApplicantContext _context;

        private readonly ILogger _logger;

        public ApplicantController(ApplicantContext context, ILoggerFactory loggerFactory)
        {
            _context = context;

            _logger = loggerFactory.CreateLogger("Hahn.ApplicationProcess.December2020.Web");
        }

        [Route("GetAllApplicants")]
        [HttpGet]
        [SwaggerOperation("Get All Applicants")]        
        public ActionResult GetAllApplicants()
        {
            try
            {
                _logger.LogInformation("Inside GetAllApplicants");

                return Ok(_context.Applicants.ToList());          
            }
            catch (Exception ex)
            {
                _logger.LogWarning("Something went wrong while fetching Applicants" + ex.Message);
                return StatusCode(500, "Internal server error");
            }
        }

        [Route("SaveApplicant")]
        [HttpPost]
        [SwaggerOperation("Save A New Applicant")]        
        public int SaveApplicant(Applicant applicant)
        {
            try
            {
                _logger.LogInformation("Inside SaveApplicant");

                if (applicant == null)
                {
                    _logger.LogWarning("Supplied Applicant is null");
                }

                if (ModelState.IsValid == false)
                {
                    _logger.LogWarning("Something is wrong in supplied values, Please review and correct them");
                }

                _context.Applicants.Add(applicant);
                _context.SaveChanges();

                //var ApplicantOptions = new DbContextOptionsBuilder<ApplicantContext>()
                //                                                       .UseInMemoryDatabase(databaseName: "Applicants")
                //                                                       .Options;

                //using (var context = new ApplicantContext(ApplicantOptions))
                //{
                //    _logger.LogInformation("Before Saving Applicant");

                //    context.Applicants.Add(applicant);
                //    context.SaveChanges();
                //}

                return 201;
            }
            catch (Exception ex)
            {
                _logger.LogWarning("Something went wrong while saving Applicant" + ex.Message);
                return 400;
            }
        }

        [Route("GetApplicant/{ApplicantId}")]
        [HttpGet]
        [SwaggerOperation("Get A Specific Applicant")]        
        public ActionResult GetApplicant(int ApplicantId)
        {
            try
            {
                _logger.LogInformation("Inside GetApplicant");

                return Ok(_context.Applicants.Find(ApplicantId));                
            }
            catch (Exception ex)
            {
                _logger.LogWarning("Something went wrong while fetching Applicant" + ex.Message);
                return StatusCode(500, "Internal Server Error");
            }
        }

        [Route("UpdateApplicant/{ApplicantId}")]
        [HttpPut]
        [SwaggerOperation("Update A Specific Applicant")]
        public int UpdateApplicant(int ApplicantId, Applicant applicant)
        {
            try
            {
                _logger.LogInformation("Inside UpdateApplicant");

                if (applicant == null)
                {
                    _logger.LogWarning("Supplied Applicant is null");
                }

                if (ModelState.IsValid == false)
                {
                    _logger.LogWarning("Something is wrong in supplied values, Please review and correct them");
                }

                var tobeupdated = _context.Applicants.Find(ApplicantId);

                if (tobeupdated == null)
                {
                    _logger.LogWarning("There is no applicant with given Id, Please correct and re-submit the request.");
                }
                else
                {
                    tobeupdated.Id = applicant.Id;
                    tobeupdated.Name = applicant.Name;
                    tobeupdated.FamilyName = applicant.FamilyName;
                    tobeupdated.Address = applicant.Address;
                    tobeupdated.CountryOfOrigin = applicant.CountryOfOrigin;
                    tobeupdated.EMailAddress = applicant.EMailAddress;
                    tobeupdated.Age = applicant.Age;
                    tobeupdated.Hired = applicant.Hired;

                    _context.Applicants.Update(tobeupdated);
                    _context.SaveChanges();
                }
                
                return 201;
            }
            catch (Exception ex)
            {
                _logger.LogWarning("Something went wrong while updating Applicant" + ex.Message);
                return 400;
            }
        }

        [Route("DeleteApplicant/{ApplicantId}")]
        [HttpDelete]
        [SwaggerOperation("Delete A Specific Applicant")]
        public int DeleteApplicant(int ApplicantId)
        {
            _logger.LogInformation("Inside DeleteApplicant");

            try
            {
                if (ModelState.IsValid == false)
                {
                    _logger.LogWarning("Something is wrong in supplied values, Please review and correct them");
                }
                
                var tobedeleted = _context.Applicants.Find(ApplicantId);

                if (tobedeleted == null)
                {
                    _logger.LogWarning("There is no applicant with given Id, Please correct and re-submit the request.");
                }
                else
                {
                    _context.Applicants.Remove(tobedeleted);
                    _context.SaveChanges();
                }

                return 201;
            }
            catch (Exception ex)
            {
                _logger.LogWarning("Something went wrong while deleting Applicant" + ex.Message);
                return 400;
            }
        }
    }
}
