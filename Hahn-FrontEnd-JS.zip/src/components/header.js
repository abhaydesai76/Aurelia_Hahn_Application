import {bindable, inject} from 'aurelia-framework';
import {I18N} from 'aurelia-i18n';

@inject(I18N)

export class Header {    
  appTitle = "Hahn Applicants";

  constructor(I18N) {
    this.i18n = I18N;      
  }

  setLocale(locale) {
    this.i18n.setLocale(locale);    
  }  
}
