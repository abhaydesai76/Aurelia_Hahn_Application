import 'bootstrap/dist/css/bootstrap.css';
import 'font-awesome/css/font-awesome.css';  
import {DialogService} from 'aurelia-dialog';
import {Prompt} from './prompt';
import {inject, NewInstance} from 'aurelia-framework';
import {ValidationController, ValidationRules, validateTrigger} from 'aurelia-validation';
import {HttpClient, json} from 'aurelia-fetch-client';

@inject(NewInstance.of(ValidationController), DialogService, HttpClient)

export class App {
    id = 0;
    name = '';
    familyName = '';
    age = 0;
    address = '';
    eMailAddress = '';
    countryOfOrigin = '';
    hired = false;
    countryValues = '';    

    hiredStatuses = [     
        {id:0, name: 'Hired'},
        {id:1, name: 'Not Hired'}     
    ]

    selectedHiredStatus = 'Not Hired';

    applicants = [];
    toBeUpdatedApplicant = {};
    toBeDeletedApplicant = {};
    controller = null;

    httpClient = new HttpClient();

    constructor(controller, dialogService, http) {

      // window.alert('Inside Constructor');

      this.controller = controller;      
      this.dialogService = dialogService;
      
      this.controller.validateTrigger = validateTrigger.change;      
      
      http.configure(config => {
        config
          .withBaseUrl('https://localhost:44348/Applicant/')
          .withDefaults({
            mode: 'cors',
            credentials: 'same-origin',
            headers: {
              // 'Content-Type': 'application/json',
              'Accept': 'application/json',
              'X-Requested-With': 'Fetch'
            }
          });
      });
      
      this.http = http;

      ValidationRules.customRule('ValidCountry', (value, obj) => {        
          var countryValue = this.http.fetch("https://restcountries.eu/rest/v2/name/" + value)
          .then(response => response.json())
          .then(countryValues => {
            console.log('value of countryValues : ', countryValues);
            this.countryValues = countryValues;

            if (this.countryValues.status === 404)
            {
              return false;
            }
            else
            {
              return true;
            }          
          })
          .catch(error => {
            console.log(`Error retrieving country : ${error}`);
            return false;
          });

          return countryValue;                
      });

      ValidationRules
        .ensure('name').required().minLength(5)
        .ensure('familyName').required().minLength(5)
        .ensure('address').required().minLength(10)
        .ensure('eMailAddress').required().email()
        .ensure('age').required().range(20,60)
        .ensure('countryOfOrigin').required().then().satisfiesRule('ValidCountry')
        .withMessage('Entered country should be a valid country!')
        .on(this);
    }

    getApplicants() {
      this.http.fetch('GetAllApplicants')
        .then(response => response.json())
        .then(applicants => {
          console.log('value of applicants in getApplicants', applicants);
          this.applicants = applicants;
        })
        .catch(error => {
          console.log(`Error retrieving applicants. ${error}`);
          return [];
        });
    }

    attached() {
      // window.alert('Inside Attached');           
    }
    
    bind() 
    {
      // window.alert('Inside Bind');      
    }    

    activate() 
    {
      // window.alert('Inside Activate');      
      this.getApplicants();
    }

    created() {
      // window.alert('Inside Created');        
      this.controller.validate();    
    }

    add() {                
      this.controller.validate()
      .then(result => {
        if (result.valid)
        {
          this.dialogService.open({ viewModel: Prompt, model: 'Do you want to save this record?', lock: false }).whenClosed(response => {
            if (!response.wasCancelled)
            {
              this.validateDetailsSave();
            }
            else
            {
              console.log('Doesnot want to save at this moment');
            }
          });      
        }
      });
    }

    update(id) {     
        this.dialogService.open({ viewModel: Prompt, model: 'Do you want to update this record?', lock: false }).whenClosed(response => {
          if (!response.wasCancelled)
          {
            console.log('value of applicants : ', this.applicants);
            this.toBeUpdatedApplicant = this.applicants.find(applicant => applicant.id === Number(id));
            console.log('toBeUpdatedApplicant : ', this.toBeUpdatedApplicant);
  
            this.id = id;
            this.name = this.toBeUpdatedApplicant.name;
            this.familyName = this.toBeUpdatedApplicant.familyName;
            this.age = this.toBeUpdatedApplicant.age;
            this.address = this.toBeUpdatedApplicant.address;
            this.eMailAddress = this.toBeUpdatedApplicant.eMailAddress;
            this.countryOfOrigin = this.toBeUpdatedApplicant.countryOfOrigin;
            this.hired = this.toBeUpdatedApplicant.hired;
          }
          else
          {
            console.log('Doesnot want to update at this moment');
          }
        });      
    }

    validateDetailsSave() {      
        if (Object.keys(this.toBeUpdatedApplicant).length === 0)
        {
          console.log('value of selectedHiredStatus : ', this.selectedHiredStatus);
          this.selectedHiredStatus === 'Hired' ? this.hired = true : this.hired = false;

          let Applicant = {name: this.name, familyName: this.familyName, address: this.address, age: Number(this.age), 
            eMailAddress: this.eMailAddress, countryOfOrigin: this.countryOfOrigin, hired: Boolean(this.hired)};

          console.log('value of Applicant : ', Applicant);

          this.http
          .fetch('SaveApplicant', {
            method: 'post',
            body: json(Applicant)
          })
          .then(response => response.json())
          .then(createdApplicant => {            
            return createdApplicant;            
          })
          .catch(error => {
              console.log(`Error adding Applicant. ${error}`);
          });
          
          this.dialogService.open({ viewModel: Prompt, model: 'Record saved successfully...', lock: false }).whenClosed(response => {          
            if (!response.wasCancelled)
            {
              location.reload();
            }
          });
        }
        else
        {
          this.controller.validate()
          .then(result => {
            if (result.valid)
            {
              this.selectedHiredStatus === 'Hired' ? this.hired = true : this.hired = false;
              
              let updatedApplicant = this.applicants.filter(applicant => applicant.id === this.id);

              updatedApplicant = {id: this.id, name: this.name, familyName: this.familyName, address: this.address, age: Number(this.age), 
                eMailAddress: this.eMailAddress, countryOfOrigin: this.countryOfOrigin, hired: Boolean(this.hired)};

              console.log('value of updatedApplicant : ', json(updatedApplicant));

              this.http
              .fetch(`UpdateApplicant/${updatedApplicant.id}`, {
                method: 'put',
                body: json(updatedApplicant)
              })
              .then(response => response.json())
              .then(updatedApplicant => {
                return updatedApplicant;
              })
              .catch(error => {
                  console.log(`Error updating Applicant. ${error}`);
              });
              
              this.dialogService.open({ viewModel: Prompt, model: 'Record updated successfully...', lock: false }).whenClosed(response => {          
                if (!response.wasCancelled)
                {
                  location.reload();
                }
              });
            }
          })
        }
        // this.clearForm();
    }       

    delete(id) {
      this.dialogService.open({ viewModel: Prompt, model: 'Do you want to delete this record?', lock: false }).whenClosed(response => {
        if (!response.wasCancelled)
        {
          this.http
          .fetch(`DeleteApplicant/${id}`, {
            method: 'delete'
          })
          .then(response => response.json())
          .then(responseMessage => {
            return responseMessage;
          })
            .catch(error => {
                console.log(`Error deleting Applicant. ${error}`);
          });
          
          this.dialogService.open({ viewModel: Prompt, model: 'Record deleted successfully...', lock: false }).whenClosed(response => {          
            if (!response.wasCancelled)
            {
              location.reload();
            }
          });
        }
        else
        {
          console.log('Doesnot want to delete at this moment');
        }
      }); 
    }

    reset() {
      this.dialogService.open({ viewModel: Prompt, model: 'Do you want to reset all fields?', lock: false }).whenClosed(response => {
        if (!response.wasCancelled)
        {
          this.controller.reset();
          this.clearForm();
        }
        else
        {
          console.log('Doesnot want to reset at this moment');
        }     
      });
    }
    
    clearForm() {
      this.id = 0;
      this.name = '';
      this.familyName = '';
      this.age = '';
      this.address = '';
      this.eMailAddress = '';
      this.countryOfOrigin = '';
      this.hired = '';
    }
}
